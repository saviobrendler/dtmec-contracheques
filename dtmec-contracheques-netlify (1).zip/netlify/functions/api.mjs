// Portal de Contracheques DT MEC - parte do servidor (Netlify Functions + Netlify Blobs)
import { getStore } from '@netlify/blobs';
import { scryptSync, randomBytes, timingSafeEqual, createHmac } from 'node:crypto';

const MAX_PDF = 4 * 1024 * 1024;      // 4 MB por PDF (limite da função)
const TENTATIVAS = 6, BLOQUEIO_MS = 15 * 60 * 1000, SESSAO_MS = 2 * 60 * 60 * 1000;
const TIPOS = { mensal: 'Mensal', adiantamento: 'Adiantamento', '13-1': '13º salário (1ª parcela)', '13-2': '13º salário (2ª parcela)', ferias: 'Férias', rescisao: 'Rescisão', outro: 'Outro' };

/* ---------- armazenamento ---------- */
const store = () => getStore({ name: 'portal', consistency: 'strong' });
const DB_VAZIO = { admins: [], funcionarios: [], contracheques: [], config: { rh_contato: '', aviso: '' }, tentativas: {}, logs: [] };
async function lerDb() {
  const r = await store().getWithMetadata('db.json', { type: 'json' });
  return r ? { db: { ...DB_VAZIO, ...r.data }, etag: r.etag || null, existe: true } : { db: structuredClone(DB_VAZIO), etag: null, existe: false };
}
// lê, altera e grava com proteção contra gravação simultânea
async function alterarDb(fn) {
  for (let i = 0; i < 5; i++) {
    const { db, etag, existe } = await lerDb();
    const out = await fn(db);
    if (out === false) return db;
    // grava só se ninguém alterou no meio (etag); sem etag disponível, grava direto
    const r = await store().set('db.json', JSON.stringify(db), etag ? { onlyIfMatch: etag } : (existe ? {} : { onlyIfNew: true }));
    if (r.modified) return db;
    await new Promise(res => setTimeout(res, 60 + Math.random() * 120));
  }
  throw new Error('Não foi possível gravar. Tente de novo.');
}
async function segredo() {
  let s = await store().get('segredo');
  if (!s) { await store().set('segredo', randomBytes(32).toString('hex'), { onlyIfNew: true }); s = await store().get('segredo'); }
  return s;
}

/* ---------- utilidades ---------- */
const agora = () => new Date().toISOString();
const id = () => randomBytes(8).toString('hex');
const digitos = s => String(s || '').replace(/\D+/g, '');
function cpfValido(c) {
  c = digitos(c); if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
  for (let t = 9; t < 11; t++) { let d = 0; for (let i = 0; i < t; i++) d += +c[i] * ((t + 1) - i); d = ((10 * d) % 11) % 10; if (+c[t] !== d) return false; }
  return true;
}
const hash = s => { const salt = randomBytes(16).toString('hex'); return salt + ':' + scryptSync(s, salt, 32).toString('hex'); };
const confere = (s, h) => { const [salt, hex] = String(h || '').split(':'); if (!salt || !hex) return false; const a = scryptSync(s, salt, 32), b = Buffer.from(hex, 'hex'); return a.length === b.length && timingSafeEqual(a, b); };
const json = (obj, status = 200, headers = {}) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers } });
const erro = (msg, status = 400) => json({ erro: msg }, status);
const b64 = s => Buffer.from(s).toString('base64url'), unb64 = s => Buffer.from(s, 'base64url').toString();
function log(db, quem, acao, detalhe = '') { db.logs.unshift({ quando: agora(), quem, acao, detalhe }); db.logs.length = Math.min(db.logs.length, 200); }
function publicoFunc(f) { const { senha_hash, ...r } = f; return { ...r, cpf_mascarado: '***.' + f.cpf.slice(3, 6) + '.' + f.cpf.slice(6, 9) + '-**' }; }

/* ---------- sessão (cookie assinado) ---------- */
async function assinar(dados) { const p = b64(JSON.stringify(dados)); const s = createHmac('sha256', await segredo()).update(p).digest('base64url'); return p + '.' + s; }
async function lerSessao(req) {
  const m = /(?:^|;\s*)dtp=([^;]+)/.exec(req.headers.get('cookie') || ''); if (!m) return null;
  const [p, s] = m[1].split('.'); if (!p || !s) return null;
  const esperado = createHmac('sha256', await segredo()).update(p).digest('base64url');
  if (esperado.length !== s.length || !timingSafeEqual(Buffer.from(esperado), Buffer.from(s))) return null;
  try { const d = JSON.parse(unb64(p)); return d.exp > Date.now() ? d : null; } catch { return null; }
}
const cookie = (v, max = SESSAO_MS / 1000) => ({ 'set-cookie': `dtp=${v}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${max}` });
function bloqueado(db, chave) { const t = db.tentativas[chave]; return t && t.n >= TENTATIVAS && t.ate > Date.now() ? Math.ceil((t.ate - Date.now()) / 60000) : 0; }
function falhou(db, chave) { const t = db.tentativas[chave]; db.tentativas[chave] = { n: t && t.ate > Date.now() ? t.n + 1 : 1, ate: Date.now() + BLOQUEIO_MS }; for (const k in db.tentativas) if (db.tentativas[k].ate < Date.now()) delete db.tentativas[k]; }

/* ---------- PDF ---------- */
async function arquivoPdf(file, nome) {
  if (!file || typeof file.arrayBuffer !== 'function') throw new Error((nome ? nome + ': ' : '') + 'arquivo não enviado.');
  if (file.size > MAX_PDF) throw new Error((nome || file.name) + ': o PDF passa de 4 MB.');
  if (file.size < 100) throw new Error((nome || file.name) + ': arquivo vazio.');
  const buf = Buffer.from(await file.arrayBuffer());
  if (buf.subarray(0, 4).toString() !== '%PDF') throw new Error((nome || file.name) + ': não é um PDF válido.');
  return buf;
}
async function entregarPdf(cc, nome, inline) {
  const buf = await store().get('pdf/' + cc.id, { type: 'arrayBuffer' });
  if (!buf) return erro('Arquivo não encontrado.', 404);
  const slug = nome.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  return new Response(buf, { headers: { 'content-type': 'application/pdf', 'content-disposition': `${inline ? 'inline' : 'attachment'}; filename="contracheque-${cc.competencia}-${slug}.pdf"`, 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' } });
}
function registrarCc(db, f, competencia, tipo, substituir) {
  const ja = db.contracheques.find(c => c.funcionario_id === f.id && c.competencia === competencia && c.tipo === tipo);
  if (ja && !substituir) throw new Error(`Já existe ${TIPOS[tipo]} de ${nomeComp(competencia)} para ${f.nome}. Marque "substituir" para trocar.`);
  return ja;
}
const MESES = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const nomeComp = c => { const [a, m] = c.split('-'); return (MESES[+m] || m) + ' de ' + a; };

/* ---------- rotas ---------- */
export default async (req) => {
  const url = new URL(req.url);
  const rota = url.pathname.replace(/^\/api\/?/, '').replace(/\/$/, '');
  const metodo = req.method;
  try {
    if (metodo !== 'GET' && req.headers.get('x-requested-with') !== 'portal') return erro('Requisição inválida.', 403);
    const sess = await lerSessao(req);
    const parte = rota.split('/');

    /* --- estado inicial --- */
    if (rota === 'estado' && metodo === 'GET') {
      const { db } = await lerDb();
      return json({ setup: db.admins.length === 0, rh_contato: db.config.rh_contato || '', aviso: db.config.aviso || '', sessao: sess ? sess.t : null });
    }
    if (rota === 'setup' && metodo === 'POST') {
      const b = await req.json(); const u = String(b.usuario || '').trim().toLowerCase(), n = String(b.nome || '').trim(), s = String(b.senha || '');
      if (!/^[a-z0-9._-]{2,40}$/.test(u)) return erro('Usuário: use de 2 a 40 letras, números, ponto, traço ou sublinhado.');
      if (!n) return erro('Informe o nome.'); if (s.length < 8) return erro('A senha precisa ter pelo menos 8 caracteres.');
      let criado = false;
      await alterarDb(db => { if (db.admins.length) return false; db.admins.push({ id: id(), usuario: u, nome: n, senha_hash: hash(s), criado_em: agora() }); log(db, 'setup', 'admin_criado', u); criado = true; });
      return criado ? json({ ok: true }) : erro('O administrador já foi criado.');
    }

    /* --- colaborador --- */
    if (rota === 'login' && metodo === 'POST') {
      const b = await req.json(); const cpf = digitos(b.cpf), senha = String(b.senha || '');
      const chave = 'f:' + cpf; let resp;
      await alterarDb(db => {
        const min = bloqueado(db, chave); if (min) { resp = erro(`Muitas tentativas. Aguarde ${min} min e tente de novo.`, 429); return false; }
        const f = cpf.length === 11 ? db.funcionarios.find(x => x.cpf === cpf) : null;
        if (!f || !confere(senha, f.senha_hash)) { falhou(db, chave); log(db, 'func:' + cpf, 'login_falhou'); resp = erro('CPF ou senha incorretos.', 401); return; }
        if (!f.ativo) { resp = erro('Seu acesso está desativado. Fale com o RH.', 403); return false; }
        delete db.tentativas[chave]; f.ultimo_acesso = agora(); log(db, 'func:' + cpf, 'login'); resp = f;
      });
      if (resp instanceof Response) return resp;
      return json({ ok: true }, 200, cookie(await assinar({ t: 'f', id: resp.id, exp: Date.now() + SESSAO_MS })));
    }
    if (rota === 'sair' && metodo === 'POST') return json({ ok: true }, 200, cookie('', 0));

    if (sess && sess.t === 'f') {
      const { db } = await lerDb(); const f = db.funcionarios.find(x => x.id === sess.id && x.ativo);
      if (!f) return json({ ok: true, expirou: true }, 401, cookie('', 0));
      if (rota === 'eu' && metodo === 'GET') {
        const lista = db.contracheques.filter(c => c.funcionario_id === f.id).sort((a, b) => b.competencia.localeCompare(a.competencia) || b.enviado_em.localeCompare(a.enviado_em)).map(c => ({ id: c.id, competencia: c.competencia, tipo: c.tipo, tipo_nome: TIPOS[c.tipo] || c.tipo, tamanho: c.tamanho, enviado_em: c.enviado_em, novo: !c.baixado_em }));
        return json({ eu: publicoFunc(f), contracheques: lista, rh_contato: db.config.rh_contato || '', aviso: db.config.aviso || '' });
      }
      if (parte[0] === 'baixar' && parte[1] && metodo === 'GET') {
        const cc = db.contracheques.find(c => c.id === parte[1] && c.funcionario_id === f.id); if (!cc) return erro('Não encontrado.', 404);
        if (!cc.baixado_em) await alterarDb(d => { const x = d.contracheques.find(c => c.id === cc.id); if (x && !x.baixado_em) x.baixado_em = agora(); log(d, 'func:' + f.cpf, 'download', cc.competencia + '/' + cc.tipo); });
        return entregarPdf(cc, f.nome, url.searchParams.get('ver') === '1');
      }
      if (rota === 'senha' && metodo === 'POST') {
        const b = await req.json(); const nova = String(b.nova || '');
        if (!confere(String(b.atual || ''), f.senha_hash)) return erro('A senha atual não confere.');
        if (nova.length < 8) return erro('A nova senha precisa ter pelo menos 8 caracteres.'); if (nova === f.cpf) return erro('A nova senha não pode ser o seu CPF.');
        await alterarDb(d => { const x = d.funcionarios.find(y => y.id === f.id); x.senha_hash = hash(nova); x.senha_padrao = false; log(d, 'func:' + f.cpf, 'senha_alterada'); });
        return json({ ok: true });
      }
    }

    /* --- RH --- */
    if (rota === 'admin/login' && metodo === 'POST') {
      const b = await req.json(); const u = String(b.usuario || '').trim().toLowerCase(), s = String(b.senha || ''); const chave = 'a:' + u; let resp;
      await alterarDb(db => {
        const min = bloqueado(db, chave); if (min) { resp = erro(`Muitas tentativas. Aguarde ${min} min.`, 429); return false; }
        const a = db.admins.find(x => x.usuario === u);
        if (!a || !confere(s, a.senha_hash)) { falhou(db, chave); log(db, 'admin:' + u, 'login_falhou'); resp = erro('Usuário ou senha incorretos.', 401); return; }
        delete db.tentativas[chave]; a.ultimo_acesso = agora(); log(db, 'admin:' + u, 'login'); resp = a;
      });
      if (resp instanceof Response) return resp;
      return json({ ok: true }, 200, cookie(await assinar({ t: 'a', id: resp.id, exp: Date.now() + SESSAO_MS })));
    }
    if (parte[0] !== 'admin') return erro('Faça login.', 401);
    if (!sess || sess.t !== 'a') return erro('Faça login como administrador.', 401);
    const { db } = await lerDb(); const adm = db.admins.find(a => a.id === sess.id); if (!adm) return erro('Faça login como administrador.', 401, cookie('', 0));
    const quem = 'admin:' + adm.usuario; const sub = parte.slice(1).join('/');

    if (sub === 'painel' && metodo === 'GET') {
      const func = db.funcionarios.map(publicoFunc).map(f => ({ ...f, n: db.contracheques.filter(c => c.funcionario_id === f.id).length })).sort((a, b) => (b.ativo - a.ativo) || a.nome.localeCompare(b.nome));
      const ccs = db.contracheques.map(c => { const f = db.funcionarios.find(x => x.id === c.funcionario_id); return { ...c, nome: f ? f.nome : '?', cpf: f ? f.cpf : '', tipo_nome: TIPOS[c.tipo] || c.tipo }; }).sort((a, b) => b.competencia.localeCompare(a.competencia) || a.nome.localeCompare(b.nome));
      return json({ admin: { nome: adm.nome, usuario: adm.usuario }, funcionarios: func, contracheques: ccs, config: db.config, logs: db.logs.slice(0, 40), tipos: TIPOS, max_pdf: MAX_PDF });
    }
    if (sub === 'funcionarios' && metodo === 'POST') {
      const b = await req.json(); const nome = String(b.nome || '').trim(), cpf = digitos(b.cpf), email = String(b.email || '').trim();
      if (nome.length < 3) return erro('Informe o nome completo.'); if (!cpfValido(cpf)) return erro('CPF inválido.');
      if (email && !/^\S+@\S+\.\S+$/.test(email)) return erro('E-mail inválido.');
      let msg = '';
      await alterarDb(d => {
        if (d.funcionarios.some(f => f.cpf === cpf && f.id !== b.id)) { msg = 'erro:Já existe um funcionário com esse CPF.'; return false; }
        const dados = { nome, cpf, matricula: String(b.matricula || '').trim(), cargo: String(b.cargo || '').trim(), email, admissao: /^\d{4}-\d{2}-\d{2}$/.test(b.admissao || '') ? b.admissao : '' };
        const f = b.id ? d.funcionarios.find(x => x.id === b.id) : null;
        if (b.id && !f) { msg = 'erro:Funcionário não encontrado.'; return false; }
        if (f) { Object.assign(f, dados); log(d, quem, 'func_editado', cpf); msg = 'Dados atualizados.'; }
        else { d.funcionarios.push({ id: id(), ...dados, ativo: true, senha_hash: hash(cpf), senha_padrao: true, criado_em: agora(), ultimo_acesso: null }); log(d, quem, 'func_criado', cpf); msg = nome + ' cadastrado. Login: CPF; senha inicial: o próprio CPF (só números).'; }
      });
      return msg.startsWith('erro:') ? erro(msg.slice(5)) : json({ ok: true, msg });
    }
    if (parte[1] === 'funcionarios' && parte[2] && parte[3] && metodo === 'POST') {
      const fid = parte[2], op = parte[3]; let msg = ''; const b = await req.json().catch(() => ({}));
      await alterarDb(async d => {
        const f = d.funcionarios.find(x => x.id === fid); if (!f) { msg = 'erro:Funcionário não encontrado.'; return false; }
        if (op === 'resetar') { f.senha_hash = hash(f.cpf); f.senha_padrao = true; log(d, quem, 'senha_resetada', f.cpf); msg = 'Senha de ' + f.nome + ' voltou a ser o CPF.'; }
        else if (op === 'ativar') { f.ativo = !f.ativo; log(d, quem, f.ativo ? 'func_ativado' : 'func_desativado', f.cpf); msg = f.nome + (f.ativo ? ' ativado.' : ' desativado.'); }
        else if (op === 'excluir') {
          if (digitos(b.confirma) !== f.cpf) { msg = 'erro:Para excluir, digite o CPF do funcionário no campo de confirmação.'; return false; }
          for (const c of d.contracheques.filter(c => c.funcionario_id === fid)) await store().delete('pdf/' + c.id);
          d.contracheques = d.contracheques.filter(c => c.funcionario_id !== fid); d.funcionarios = d.funcionarios.filter(x => x.id !== fid); log(d, quem, 'func_excluido', f.cpf); msg = f.nome + ' e seus contracheques foram excluídos.';
        } else { msg = 'erro:Operação inválida.'; return false; }
      });
      return msg.startsWith('erro:') ? erro(msg.slice(5)) : json({ ok: true, msg });
    }
    if (sub === 'contracheques' && metodo === 'POST') {
      const fd = await req.formData(); const competencia = String(fd.get('competencia') || ''), tipo = String(fd.get('tipo') || ''), substituir = fd.get('substituir') === '1', file = fd.get('pdf');
      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(competencia)) return erro('Informe a competência (mês/ano).'); if (!TIPOS[tipo]) return erro('Tipo inválido.');
      let f; const fid = String(fd.get('funcionario_id') || ''), nomeArq = file && file.name ? file.name : '';
      if (fid) f = db.funcionarios.find(x => x.id === fid);
      else { const m = /(\d{3}\.?\d{3}\.?\d{3}-?\d{2})/.exec(nomeArq); if (!m) return erro(nomeArq + ': o nome do arquivo não tem CPF.'); f = db.funcionarios.find(x => x.cpf === digitos(m[1])); if (!f) return erro(nomeArq + ': CPF ' + m[1] + ' não está cadastrado.'); }
      if (!f) return erro('Escolha o funcionário.');
      let buf; try { registrarCc(db, f, competencia, tipo, substituir); buf = await arquivoPdf(file, nomeArq); } catch (ex) { return erro(ex.message); }
      const novoId = id(); await store().set('pdf/' + novoId, buf, { metadata: { funcionario: f.cpf, competencia, tipo } });
      let msg = '';
      await alterarDb(async d => {
        const ff = d.funcionarios.find(x => x.id === f.id); if (!ff) { msg = 'erro:Funcionário não encontrado.'; return false; }
        const ja = d.contracheques.find(c => c.funcionario_id === f.id && c.competencia === competencia && c.tipo === tipo);
        if (ja) { await store().delete('pdf/' + ja.id); ja.id = novoId; ja.tamanho = buf.length; ja.nome_original = nomeArq; ja.enviado_em = agora(); ja.baixado_em = null; log(d, quem, 'cc_substituido', competencia + '/' + tipo + ' ' + f.cpf); }
        else { d.contracheques.push({ id: novoId, funcionario_id: f.id, competencia, tipo, tamanho: buf.length, nome_original: nomeArq, enviado_em: agora(), baixado_em: null }); log(d, quem, 'cc_enviado', competencia + '/' + tipo + ' ' + f.cpf); }
        msg = f.nome + ': ' + TIPOS[tipo] + ' de ' + nomeComp(competencia) + (ja ? ' substituído.' : ' enviado.');
      });
      return msg.startsWith('erro:') ? erro(msg.slice(5)) : json({ ok: true, msg });
    }
    if (parte[1] === 'contracheques' && parte[2] && metodo === 'DELETE') {
      const cc = db.contracheques.find(c => c.id === parte[2]); if (!cc) return erro('Não encontrado.', 404);
      await store().delete('pdf/' + cc.id);
      await alterarDb(d => { d.contracheques = d.contracheques.filter(c => c.id !== cc.id); log(d, quem, 'cc_excluido', cc.competencia + ' ' + cc.funcionario_id); });
      return json({ ok: true, msg: 'Contracheque excluído.' });
    }
    if (parte[1] === 'baixar' && parte[2] && metodo === 'GET') {
      const cc = db.contracheques.find(c => c.id === parte[2]); if (!cc) return erro('Não encontrado.', 404);
      const f = db.funcionarios.find(x => x.id === cc.funcionario_id); return entregarPdf(cc, f ? f.nome : 'contracheque', url.searchParams.get('ver') === '1');
    }
    if (sub === 'config' && metodo === 'POST') {
      const b = await req.json();
      await alterarDb(d => { d.config.rh_contato = String(b.rh_contato || '').slice(0, 200); d.config.aviso = String(b.aviso || '').slice(0, 400); });
      return json({ ok: true, msg: 'Configurações salvas.' });
    }
    if (sub === 'senha' && metodo === 'POST') {
      const b = await req.json(); if (!confere(String(b.atual || ''), adm.senha_hash)) return erro('Senha atual não confere.'); if (String(b.nova || '').length < 8) return erro('A senha precisa ter pelo menos 8 caracteres.');
      await alterarDb(d => { d.admins.find(a => a.id === adm.id).senha_hash = hash(b.nova); log(d, quem, 'senha_admin_alterada'); });
      return json({ ok: true, msg: 'Senha alterada.' });
    }
    if (sub === 'novo-admin' && metodo === 'POST') {
      const b = await req.json(); const u = String(b.usuario || '').trim().toLowerCase();
      if (!/^[a-z0-9._-]{2,40}$/.test(u)) return erro('Usuário inválido.'); if (String(b.senha || '').length < 8) return erro('A senha precisa ter pelo menos 8 caracteres.');
      let msg = '';
      await alterarDb(d => { if (d.admins.some(a => a.usuario === u)) { msg = 'erro:Esse usuário já existe.'; return false; } d.admins.push({ id: id(), usuario: u, nome: String(b.nome || u).trim() || u, senha_hash: hash(b.senha), criado_em: agora() }); log(d, quem, 'admin_criado', u); msg = 'Administrador ' + u + ' criado.'; });
      return msg.startsWith('erro:') ? erro(msg.slice(5)) : json({ ok: true, msg });
    }
    if (sub === 'sair' && metodo === 'POST') return json({ ok: true }, 200, cookie('', 0));
    return erro('Rota não encontrada.', 404);
  } catch (ex) {
    console.error(ex);
    return erro('Erro no servidor: ' + (ex && ex.message ? ex.message : 'tente de novo.'), 500);
  }
};
export const config = { path: '/api/*' };
