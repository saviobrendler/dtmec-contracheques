(function () {
  var $ = P.$, e = P.e, api = P.api, ico = P.ico;
  P.ligar();
  function sair() { api('sair', { body: {} }).catch(function () {}).then(function () { location.reload(); }); }
  $('#b-sair').addEventListener('click', sair); $('#b-sair2').addEventListener('click', sair);
  $('#b-senha').addEventListener('click', function () { P.tela('t-senha'); $('#atual').focus(); });
  $('#l-senha').addEventListener('click', function (ev) { ev.preventDefault(); P.tela('t-senha'); $('#atual').focus(); });
  $('#b-cancelar').addEventListener('click', function () { P.tela('t-app'); });

  function estado() {
    api('estado').then(function (s) {
      if (s.rh_contato) $('#rh-foot').innerHTML = 'Dúvidas: ' + e(s.rh_contato) + '<br>';
      if (s.sessao === 'f') carregar(); else P.tela('t-login');
    }).catch(function (er) { P.tela('t-login'); P.msg('#m-login', 'erro', er.message); });
  }
  function carregar() {
    api('eu').then(function (d) {
      var u = d.eu, primeiro = u.nome.trim().split(/\s+/)[0];
      $('#av').textContent = P.iniciais(u.nome); $('#nome-topo').textContent = u.nome; $('#ola').textContent = 'Olá, ' + primeiro;
      var dl = '<dt>Nome</dt><dd>' + e(u.nome) + '</dd><dt>CPF</dt><dd>' + e(u.cpf_mascarado) + '</dd>';
      if (u.matricula) dl += '<dt>Matrícula</dt><dd>' + e(u.matricula) + '</dd>'; if (u.cargo) dl += '<dt>Cargo</dt><dd>' + e(u.cargo) + '</dd>'; if (u.admissao) dl += '<dt>Admissão</dt><dd>' + e(P.dataBr(u.admissao)) + '</dd>';
      $('#dados').innerHTML = dl;
      $('#aviso-senha').classList.toggle('hide', !u.senha_padrao);
      $('#aviso-rh').classList.toggle('hide', !d.aviso); $('#aviso-rh-t').textContent = d.aviso || '';
      $('#rh-hint').classList.toggle('hide', !d.rh_contato); $('#rh-hint').textContent = d.rh_contato ? 'Algum dado errado? Fale com o RH: ' + d.rh_contato : '';
      var h = '', ano = '';
      if (!d.contracheques.length) h = '<div class="box vazio"><div class="hx hex">' + ico('file') + '</div><strong>Nenhum contracheque ainda</strong><br>Assim que o RH enviar, ele aparece aqui.</div>';
      else {
        d.contracheques.forEach(function (c) {
          var a = c.competencia.slice(0, 4), m = +c.competencia.slice(5, 7);
          if (a !== ano) { if (ano) h += '</ul>'; h += '<div class="ano">' + e(a) + '</div><ul class="cc">'; ano = a; }
          var nomeC = P.comp(c.competencia);
          h += '<li><div class="m hex" aria-hidden="true"><b>' + ('0' + m).slice(-2) + '</b><small>' + e(nomeC.slice(0, 3)) + '</small></div><div class="t"><strong>' + e(nomeC) + (c.tipo !== 'mensal' ? '<span class="chip">' + e(c.tipo_nome) + '</span>' : '') + (c.novo ? '<span class="chip novo">Novo</span>' : '') + '</strong><span>PDF, ' + P.tam(c.tamanho) + ' · enviado em ' + P.dataBr(c.enviado_em) + '</span></div>'
            + '<div class="a"><a class="btn b-y" href="/api/baixar/' + e(c.id) + '" data-dl>' + ico('dl') + 'Baixar PDF</a><a class="btn b-ol ic" href="/api/baixar/' + e(c.id) + '?ver=1" target="_blank" rel="noopener" aria-label="Abrir ' + e(nomeC) + ' em nova aba">' + ico('eye') + '</a></div></li>';
        });
        h += '</ul>';
      }
      $('#lista').innerHTML = h;
      P.$$('[data-dl]').forEach(function (a) { a.addEventListener('click', function () { var li = a.closest('li'), n = li.querySelector('.chip.novo'); if (n) setTimeout(function () { n.remove(); }, 1500); }); });
      P.tela('t-app');
    }).catch(function (er) { P.tela('t-login'); if (!er.expirou) P.msg('#m-login', 'erro', er.message); });
  }
  $('#f-login').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; P.msg('#m-login', '', '');
    var cpf = $('#cpf').value.replace(/\D/g, ''), senha = $('#senha').value;
    if (cpf.length !== 11) { P.msg('#m-login', 'erro', 'Digite o CPF completo.'); $('#cpf').focus(); return; }
    if (!senha) { P.msg('#m-login', 'erro', 'Digite a senha.'); $('#senha').focus(); return; }
    P.ocupado(f, true, 'Entrando...');
    api('login', { body: { cpf: cpf, senha: senha } }).then(function () { $('#senha').value = ''; carregar(); }).catch(function (er) { P.msg('#m-login', 'erro', er.message); }).then(function () { P.ocupado(f, false); });
  });
  $('#f-senha').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; P.msg('#m-senha', '', '');
    var a = $('#atual').value, n = $('#nova').value, n2 = $('#nova2').value;
    if (n.length < 8) { P.msg('#m-senha', 'erro', 'A nova senha precisa ter pelo menos 8 caracteres.'); return; }
    if (n !== n2) { P.msg('#m-senha', 'erro', 'As senhas não conferem.'); return; }
    P.ocupado(f, true, 'Salvando...');
    api('senha', { body: { atual: a, nova: n } }).then(function () { f.reset(); P.toast('Senha alterada.', 'ok'); carregar(); }).catch(function (er) { P.msg('#m-senha', 'erro', er.message); }).then(function () { P.ocupado(f, false); });
  });
  estado();
})();
