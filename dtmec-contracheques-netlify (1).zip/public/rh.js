(function () {
  var $ = P.$, $$ = P.$$, e = P.e, api = P.api, ico = P.ico, D = null, edit = null;
  P.ligar();
  var mesPassado = (function () { var d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2); })();
  function sair() { api('admin/sair', { body: {} }).catch(function () {}).then(function () { location.href = '/rh'; }); }
  $('#b-sair').addEventListener('click', sair);
  function aba(n) { $$('.aba').forEach(function (s) { s.classList.toggle('on', s.id === 'aba-' + n); s.style.display = s.id === 'aba-' + n ? '' : 'none'; }); $$('.tabs a').forEach(function (a) { if (a.dataset.aba === n) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }); window.scrollTo(0, 0); }
  window.addEventListener('hashchange', function () { aba((location.hash || '#cc').slice(1)); });
  function falha(er) { if (er.status === 401) { location.reload(); return; } P.toast(er.message, 'erro'); }

  function estado() {
    api('estado').then(function (s) { if (s.setup) P.tela('t-setup'); else if (s.sessao === 'a') carregar(); else P.tela('t-login'); }).catch(function (er) { P.tela('t-login'); P.msg('#m-login', 'erro', er.message); });
  }
  function opcoesFunc(sel, todos) {
    var h = todos ? '<option value="">Todos os funcionários</option>' : '<option value="">Escolha...</option>';
    D.funcionarios.slice().sort(function (a, b) { return a.nome.localeCompare(b.nome); }).forEach(function (f) { h += '<option value="' + e(f.id) + '">' + e(f.nome) + ' · ' + e(P.cpfFmt(f.cpf)) + (f.ativo ? '' : ' (inativo)') + '</option>'; });
    var v = sel.value; sel.innerHTML = h; sel.value = v;
  }
  function carregar(manterAba) {
    return api('admin/painel').then(function (d) {
      D = d; $('#av').textContent = P.iniciais(d.admin.nome); $('#nome-topo').textContent = d.admin.nome;
      $('#k-fa').textContent = d.funcionarios.filter(function (f) { return f.ativo; }).length; $('#k-cc').textContent = d.contracheques.length; $('#k-nb').textContent = d.contracheques.filter(function (c) { return !c.baixado_em; }).length;
      ['#u-tipo', '#l-tipo'].forEach(function (s) { var sel = $(s), v = sel.value; sel.innerHTML = Object.keys(d.tipos).map(function (k) { return '<option value="' + k + '">' + e(d.tipos[k]) + '</option>'; }).join(''); if (v) sel.value = v; });
      if (!$('#u-comp').value) $('#u-comp').value = mesPassado; if (!$('#l-comp').value) $('#l-comp').value = mesPassado;
      opcoesFunc($('#u-func'), false); opcoesFunc($('#fi-func'), true);
      $('#c-rh').value = d.config.rh_contato || ''; $('#c-aviso').value = d.config.aviso || '';
      tabelaCc(); tabelaFunc(); tabelaLogs();
      P.tela('t-app'); aba((location.hash || '#cc').slice(1));
    }).catch(function (er) { P.tela('t-login'); if (!er.expirou) P.msg('#m-login', 'erro', er.message); });
  }
  function tabelaCc() {
    var f = $('#fi-func').value, c = $('#fi-comp').value;
    var l = D.contracheques.filter(function (x) { return (!f || x.funcionario_id === f) && (!c || x.competencia === c); });
    if (!l.length) { $('#tbl-cc').innerHTML = '<p class="vazio">Nenhum contracheque' + (f || c ? ' com esse filtro' : ' ainda') + '.</p>'; return; }
    var h = '<table class="tbl"><thead><tr><th>Funcionário</th><th>Competência</th><th>Tipo</th><th>Status</th><th><span class="sr">Ações</span></th></tr></thead><tbody>';
    l.slice(0, 300).forEach(function (x) {
      h += '<tr><td data-l="Funcionário"><strong>' + e(x.nome) + '</strong><br><small>' + e(P.cpfFmt(x.cpf)) + '</small></td><td data-l="Competência">' + e(P.comp(x.competencia)) + '</td><td data-l="Tipo">' + e(x.tipo_nome) + '</td><td data-l="Status">' + (x.baixado_em ? 'Baixado em ' + e(P.dataBr(x.baixado_em, true)) : '<span class="chip novo">Não baixado</span>') + '</td>'
        + '<td><div class="acts"><a class="btn b-ol b-sm" href="/api/admin/baixar/' + e(x.id) + '?ver=1" target="_blank" rel="noopener">' + ico('eye') + 'Ver</a><button class="btn b-red b-sm" type="button" data-del="' + e(x.id) + '" data-n="' + e(x.nome + ' (' + P.comp(x.competencia) + ')') + '">' + ico('trash') + 'Excluir</button></div></td></tr>';
    });
    $('#tbl-cc').innerHTML = h + '</tbody></table>';
    $$('[data-del]').forEach(function (b) { b.addEventListener('click', function () { if (!confirm('Excluir o contracheque de ' + b.dataset.n + '?')) return; b.disabled = true; api('admin/contracheques/' + b.dataset.del, { method: 'DELETE' }).then(function (r) { P.toast(r.msg, 'ok'); carregar(); }).catch(falha); }); });
  }
  function tabelaFunc() {
    var q = $('#q').value.trim().toLowerCase(), qd = q.replace(/\D/g, '');
    var l = D.funcionarios.filter(function (f) { return !q || f.nome.toLowerCase().indexOf(q) >= 0 || (qd && f.cpf.indexOf(qd) >= 0) || (f.matricula || '').toLowerCase().indexOf(q) >= 0; });
    $('#n-func').textContent = l.length;
    if (!l.length) { $('#tbl-func').innerHTML = '<p class="vazio">' + (q ? 'Ninguém encontrado.' : 'Ninguém cadastrado ainda.') + '</p>'; return; }
    var h = '<table class="tbl"><thead><tr><th>Nome</th><th>CPF</th><th>Cargo</th><th>Contracheques</th><th><span class="sr">Ações</span></th></tr></thead><tbody>';
    l.forEach(function (f) {
      h += '<tr class="' + (f.ativo ? '' : 'off') + '"><td data-l="Nome"><strong>' + e(f.nome) + '</strong>' + (f.ativo ? '' : ' <span class="chip">Inativo</span>') + (f.senha_padrao ? '' : ' <span class="chip">senha própria</span>') + '</td><td data-l="CPF">' + e(P.cpfFmt(f.cpf)) + '</td><td data-l="Cargo">' + e(f.cargo || '-') + '</td><td data-l="Contracheques">' + f.n + '</td>'
        + '<td><div class="acts"><button class="btn b-ol b-sm" type="button" data-edit="' + e(f.id) + '">' + ico('edit') + 'Editar</button><button class="btn b-ol b-sm" type="button" data-enviar="' + e(f.id) + '">' + ico('up') + 'Enviar</button></div></td></tr>';
    });
    $('#tbl-func').innerHTML = h + '</tbody></table>';
    $$('[data-edit]').forEach(function (b) { b.addEventListener('click', function () { editar(b.dataset.edit); }); });
    $$('[data-enviar]').forEach(function (b) { b.addEventListener('click', function () { $('#u-func').value = b.dataset.enviar; location.hash = '#cc'; aba('cc'); $('#u-comp').focus(); }); });
  }
  function tabelaLogs() {
    var h = '<table class="tbl"><thead><tr><th>Quando</th><th>Quem</th><th>Ação</th><th>Detalhe</th></tr></thead><tbody>';
    D.logs.forEach(function (l) { h += '<tr><td data-l="Quando">' + e(P.dataBr(l.quando, true)) + '</td><td data-l="Quem">' + e(l.quem) + '</td><td data-l="Ação">' + e(l.acao.replace(/_/g, ' ')) + '</td><td data-l="Detalhe">' + e(l.detalhe || '-') + '</td></tr>'; });
    $('#tbl-logs').innerHTML = h + '</tbody></table>';
  }
  function editar(id) {
    edit = D.funcionarios.find(function (f) { return f.id === id; }); if (!edit) return;
    $('#f-func-t').innerHTML = ico('edit') + 'Editar funcionário'; $('#e-id').value = edit.id; $('#e-nome').value = edit.nome; $('#e-cpf').value = P.cpfFmt(edit.cpf); $('#e-mat').value = edit.matricula || ''; $('#e-cargo').value = edit.cargo || ''; $('#e-email').value = edit.email || ''; $('#e-adm').value = edit.admissao || '';
    $('#f-func [type=submit] span').textContent = 'Salvar alterações'; $('#e-cancelar').classList.remove('hide');
    $('#box-acesso').classList.remove('hide'); $('#box-excluir').classList.remove('hide'); $('#a-nome').textContent = edit.nome.split(' ')[0];
    $('#a-info').textContent = 'Último acesso: ' + P.dataBr(edit.ultimo_acesso, true) + ' · Senha: ' + (edit.senha_padrao ? 'ainda é o CPF' : 'própria') + ' · Status: ' + (edit.ativo ? 'ativo' : 'desativado');
    $('#a-ativar').innerHTML = ico(edit.ativo ? 'x' : 'ok') + (edit.ativo ? 'Desativar acesso' : 'Reativar acesso');
    window.scrollTo(0, 0); $('#e-nome').focus();
  }
  function limparEdit() { edit = null; $('#f-func').reset(); $('#e-id').value = ''; $('#f-func-t').innerHTML = ico('users') + 'Cadastrar funcionário'; $('#f-func [type=submit] span').textContent = 'Cadastrar'; $('#e-cancelar').classList.add('hide'); $('#box-acesso').classList.add('hide'); $('#box-excluir').classList.add('hide'); }
  $('#e-cancelar').addEventListener('click', limparEdit);
  function acao(op, body) { if (!edit) return; api('admin/funcionarios/' + edit.id + '/' + op, { body: body || {} }).then(function (r) { P.toast(r.msg, 'ok'); limparEdit(); carregar(); }).catch(falha); }
  $('#a-resetar').addEventListener('click', function () { if (confirm('Voltar a senha para o CPF?')) acao('resetar'); });
  $('#a-ativar').addEventListener('click', function () { acao('ativar'); });
  $('#a-excluir').addEventListener('click', function () { if (confirm('Essa ação não tem volta. Excluir mesmo?')) acao('excluir', { confirma: $('#x-confirma').value }); });
  $('#q').addEventListener('input', tabelaFunc); $('#fi-func').addEventListener('change', tabelaCc); $('#fi-comp').addEventListener('change', tabelaCc);
  $('#fi-limpar').addEventListener('click', function () { $('#fi-func').value = ''; $('#fi-comp').value = ''; tabelaCc(); });

  $('#f-setup').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; P.msg('#m-setup', '', '');
    if ($('#s-senha').value !== $('#s-senha2').value) { P.msg('#m-setup', 'erro', 'As senhas não conferem.'); return; }
    P.ocupado(f, true, 'Criando...');
    api('setup', { body: { nome: $('#s-nome').value, usuario: $('#s-usuario').value, senha: $('#s-senha').value } }).then(function () { P.tela('t-login'); P.msg('#m-login', 'ok', 'Administrador criado. Agora faça login.'); $('#usuario').value = $('#s-usuario').value.trim().toLowerCase(); $('#senha').focus(); }).catch(function (er) { P.msg('#m-setup', 'erro', er.message); }).then(function () { P.ocupado(f, false); });
  });
  $('#f-login').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; P.msg('#m-login', '', ''); P.ocupado(f, true, 'Entrando...');
    api('admin/login', { body: { usuario: $('#usuario').value, senha: $('#senha').value } }).then(function () { $('#senha').value = ''; return carregar(); }).catch(function (er) { P.msg('#m-login', 'erro', er.message); }).then(function () { P.ocupado(f, false); });
  });
  $('#f-func').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; P.ocupado(f, true, 'Salvando...');
    api('admin/funcionarios', { body: { id: $('#e-id').value || undefined, nome: $('#e-nome').value, cpf: $('#e-cpf').value, matricula: $('#e-mat').value, cargo: $('#e-cargo').value, email: $('#e-email').value, admissao: $('#e-adm').value } })
      .then(function (r) { P.toast(r.msg, 'ok'); limparEdit(); carregar(); }).catch(falha).then(function () { P.ocupado(f, false); });
  });
  function enviarPdf(file, comp, tipo, subst, funcId) {
    var fd = new FormData(); fd.append('competencia', comp); fd.append('tipo', tipo); fd.append('substituir', subst ? '1' : '0'); if (funcId) fd.append('funcionario_id', funcId); fd.append('pdf', file, file.name);
    return api('admin/contracheques', { body: fd });
  }
  $('#f-um').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target, file = $('#u-pdf').files[0];
    if (!$('#u-func').value) { P.toast('Escolha o funcionário.', 'erro'); $('#u-func').focus(); return; } if (!$('#u-comp').value) { P.toast('Informe a competência.', 'erro'); return; } if (!file) { P.toast('Selecione o PDF.', 'erro'); return; }
    if (file.size > D.max_pdf) { P.toast('O PDF passa de 4 MB.', 'erro'); return; }
    P.ocupado(f, true, 'Enviando...');
    enviarPdf(file, $('#u-comp').value, $('#u-tipo').value, $('#u-subst').checked, $('#u-func').value).then(function (r) { P.toast(r.msg, 'ok'); $('#u-pdf').value = ''; $('#u-subst').checked = false; carregar(); }).catch(falha).then(function () { P.ocupado(f, false); });
  });
  $('#f-lote').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target, files = Array.prototype.slice.call($('#l-pdfs').files);
    if (!files.length) { P.toast('Selecione os PDFs.', 'erro'); return; } if (!$('#l-comp').value) { P.toast('Informe a competência.', 'erro'); return; }
    var res = $('#l-res'), prog = $('#l-prog'), ok = 0, i = 0; res.innerHTML = ''; P.ocupado(f, true, 'Enviando lote...');
    (function prox() {
      if (i >= files.length) { prog.textContent = ok + ' de ' + files.length + ' enviados.'; P.ocupado(f, false); $('#l-pdfs').value = ''; carregar(); return; }
      var file = files[i++]; prog.textContent = 'Enviando ' + i + ' de ' + files.length + ': ' + file.name;
      (file.size > D.max_pdf ? Promise.reject(new Error(file.name + ': o PDF passa de 4 MB.')) : enviarPdf(file, $('#l-comp').value, $('#l-tipo').value, $('#l-subst').checked, ''))
        .then(function (r) { ok++; res.innerHTML += '<li class="ok">' + e(r.msg) + '</li>'; }, function (er) { if (er.status === 401) { location.reload(); return; } res.innerHTML += '<li class="erro">' + e(er.message) + '</li>'; }).then(prox);
    })();
  });
  $('#f-conf').addEventListener('submit', function (ev) { ev.preventDefault(); var f = ev.target; P.ocupado(f, true, 'Salvando...'); api('admin/config', { body: { rh_contato: $('#c-rh').value, aviso: $('#c-aviso').value } }).then(function (r) { P.toast(r.msg, 'ok'); }).catch(falha).then(function () { P.ocupado(f, false); }); });
  $('#f-senha').addEventListener('submit', function (ev) {
    ev.preventDefault(); var f = ev.target; if ($('#p-nova').value !== $('#p-nova2').value) { P.toast('As senhas não conferem.', 'erro'); return; }
    P.ocupado(f, true, 'Salvando...'); api('admin/senha', { body: { atual: $('#p-atual').value, nova: $('#p-nova').value } }).then(function (r) { P.toast(r.msg, 'ok'); f.reset(); }).catch(falha).then(function () { P.ocupado(f, false); });
  });
  $('#f-novoadm').addEventListener('submit', function (ev) { ev.preventDefault(); var f = ev.target; P.ocupado(f, true, 'Criando...'); api('admin/novo-admin', { body: { nome: $('#n-nome').value, usuario: $('#n-usuario').value, senha: $('#n-senha').value } }).then(function (r) { P.toast(r.msg, 'ok'); f.reset(); carregar(); }).catch(falha).then(function () { P.ocupado(f, false); }); });
  estado();
})();
