/* funções compartilhadas (colaborador e RH) */
window.P = (function () {
  var $ = function (s, r) { return (r || document).querySelector(s); }, $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function e(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var MESES = ['', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  function comp(c) { var p = c.split('-'); return (MESES[+p[1]] || p[1]) + ' de ' + p[0]; }
  function dataBr(iso, hora) { if (!iso) return '-'; var d = new Date(iso); if (isNaN(d)) return iso; var s = ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); return hora ? s + ' ' + ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) : s; }
  function tam(b) { return b >= 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.round(b / 1024) + ' KB'; }
  function cpfFmt(c) { c = String(c || '').replace(/\D/g, ''); return c.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4'); }
  var ico = function (n) { return '<svg aria-hidden="true"><use href="#i-' + n + '"/></svg>'; };
  function msg(el, tipo, texto) { el = typeof el === 'string' ? $(el) : el; el.innerHTML = texto ? '<div class="msg ' + tipo + '" role="' + (tipo === 'erro' ? 'alert' : 'status') + '">' + ico(tipo === 'ok' ? 'ok' : tipo === 'erro' ? 'x' : 'info') + '<span>' + e(texto) + '</span></div>' : ''; if (texto && tipo === 'erro') { el.firstChild.setAttribute('tabindex', '-1'); el.firstChild.focus(); } }
  var tt; function toast(texto, tipo) { var t = $('#toast'); t.textContent = texto; t.className = 'toast on ' + (tipo || ''); clearTimeout(tt); tt = setTimeout(function () { t.className = 'toast'; }, 3500); }
  function api(rota, opts) {
    opts = opts || {}; var h = { 'X-Requested-With': 'portal' }; var body = opts.body;
    if (body && !(body instanceof FormData)) { h['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
    return fetch('/api/' + rota, { method: opts.method || (body ? 'POST' : 'GET'), headers: h, body: body, credentials: 'same-origin' }).then(function (r) {
      return r.json().catch(function () { return { erro: 'Resposta inválida do servidor.' }; }).then(function (j) { if (!r.ok) { var er = new Error(j.erro || 'Erro ' + r.status); er.status = r.status; er.expirou = j.expirou; throw er; } return j; });
    });
  }
  function tela(id) { $$('.tela').forEach(function (t) { t.classList.toggle('on', t.id === id); }); $('#carregando').classList.add('hide'); window.scrollTo(0, 0); }
  function ocupado(form, on, txt) { var b = form.querySelector('[type=submit]'); if (!b) return; b.disabled = on; var s = b.querySelector('span'); if (s) { if (on) { s.dataset.t = s.textContent; s.textContent = txt || 'Enviando...'; } else if (s.dataset.t) s.textContent = s.dataset.t; } }
  function iniciais(n) { n = (n || '').trim().split(/\s+/); return ((n[0] || '').charAt(0) + (n.length > 1 ? n[n.length - 1].charAt(0) : '')).toUpperCase(); }
  function ligar() {
    $$('.pw button').forEach(function (b) { if (b.dataset.ok) return; b.dataset.ok = 1; b.addEventListener('click', function () { var i = b.parentNode.querySelector('input'), s = i.type === 'password'; i.type = s ? 'text' : 'password'; b.setAttribute('aria-label', s ? 'Ocultar senha' : 'Mostrar senha'); b.innerHTML = ico(s ? 'eyeoff' : 'eye'); i.focus(); }); });
    $$('input[data-cpf]').forEach(function (i) { if (i.dataset.ok) return; i.dataset.ok = 1; i.addEventListener('input', function () { var v = i.value.replace(/\D/g, '').slice(0, 11); i.value = v.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2'); }); });
  }
  return { $: $, $$: $$, e: e, comp: comp, dataBr: dataBr, tam: tam, cpfFmt: cpfFmt, ico: ico, msg: msg, toast: toast, api: api, tela: tela, ocupado: ocupado, iniciais: iniciais, ligar: ligar };
})();
